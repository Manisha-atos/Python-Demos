class A:
    
    def add(self,a,b):
        print(self.a+self.b)
    def add(self,a,b,c):
        d=self.a+self.b+self.c
        print(d)
        
a1=A()
a1.add(1,1)
a1.add(1,2,3)

        
    