import mysql.connector as sql
connection = sql.connect(host="localhost",user="root",password="root")
print(connection)
cursor  = connection.cursor()
cursor.execute("use student")
#cursor.execute("create database student1")
'''cursor.execute("show databases")
for x in cursor:
   print(x)
   
cursor.execute("use student")
cursor.execute("create table employee(eid int,ename varchar(20),salary float)")
query="insert into employee values(1,'Prasad',590000)"
cursor.execute(query)
connection.commit()
cursor.execute("use student")

a=int(input("enter eid"))
b=input("enter name")
c=float(input("enter salary"))
query="insert into employee values(%d,'%s',%f)" % (a,b,c)
cursor.execute(query)
connection.commit()

sql = "INSERT INTO employee (eid, ename,salary) VALUES (%s, %s,%s)"
val = [
  (11,'Ajay',34000),
  (12,'Kumar',45000),
  (13,'Bharat',78000),
  (14,'Singh',600000),
  (15,'Santosh',98000)
  
]
cursor.executemany(sql, val)
connection.commit()

query = "delete from employee where eid=101"
cursor.execute(query)
connection.commit()


query = "update employee set ename='Deepak' where eid=11"
cursor.execute(query)
connection.commit()

query="select * from employee"
cursor.execute(query)
for i in cursor.fetchall():
    print(i)'''
    
query = "drop database student"
cursor.execute(query)