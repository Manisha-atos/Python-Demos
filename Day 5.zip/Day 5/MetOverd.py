class A:
    _x=100
    def show(self):
        print('x=%d' % self._x)
        print('class A');
class B(A):
    _x=200
    def show(self):
        print('class B');
        print(self._x)
        print(super()._x)
        super().show()
    def display(self):
        print("hi")

class C(B):
    def show(self):
        print('class C')
        
c =C()
c.show()
c.display()
c=A()
c.show()
c=B()
c.show()


'''b=A()
b.show()
print(b._x)
b=B()
b.show()
b=C()
b.show();'''