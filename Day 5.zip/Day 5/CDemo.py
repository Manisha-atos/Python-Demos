class A:
        def add(self,a,b):
            c=a+b
            print(c)
    
a1 =A()
a1.add(11,12)
a1.add(1,1)


    
