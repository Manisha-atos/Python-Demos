import math
#abc module is used for abstraction 
import abc
from abc import ABC,abstractmethod
class Shape(ABC):
    @abstractmethod
    def area(self):
        pass;
    
class circle(Shape):
    def display(self):
        print('Circle...')
    def area(self):
        print(math.pi*2.2*2.2)
        
c=circle()
c.display()
        
        
        
