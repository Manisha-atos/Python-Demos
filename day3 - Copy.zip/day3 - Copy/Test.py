import calendar
import datetime
print(calendar.prcal(2024))
#print(calendar.isleap(2023))
#print(calendar.monthcalendar(2023,7))
#print(calendar.prmonth(2014,1))

