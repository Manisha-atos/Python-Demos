import json
f=open("emp.json","r")
obj=f.read();
result=json.loads(obj);
#print(result)
#print(len(result))
#print(result.get("Records"))
l1=result.get("Records")
#print(l1)

for x in l1:
    print(x)
    print(x.get("ID"));
    print(x.get("loc"))

    #print(result.get(x));

'''for x in range(len(result)):
    print(result["Records"][x]);
   
l1=[1,2,3,4] 
for x in l1:
    print(x)'''
 
