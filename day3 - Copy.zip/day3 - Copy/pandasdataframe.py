#pip install pandas
import pandas as pd
import xlsxwriter     
df = pd.read_csv("titanic.csv")
print(df)

df1 = pd.read_json("emp.json")
print(df1)

xls = pd.ExcelFile('student.xls')
df1 = pd.read_excel(xls, 'student')
print(df1)
df2 = pd.read_excel(xls, 'titanic')
print(df2)