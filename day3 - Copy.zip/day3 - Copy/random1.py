import random
print(random.random())
print(random.randint(5,6))
print(random.randint(6,15))
