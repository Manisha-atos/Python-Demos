import csv
f=open("titanic.csv","r")
with f:
    r=csv.reader(f)
    for row in r:
        print(row)