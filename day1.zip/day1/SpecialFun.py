'''a=chr(65)
b=ord('A')
print(a)
print(b)
name=input ("enter name");
age=input ("enter age")
print(name+age)
n1=input("enter n1")
n2=input("neter n2")
print(n1+n2)# return concatination
#Type casting()
n1=int(input("enter n1"))
n2=int(input("neter n2"))
print(n1+n2)'''

color=["red","green","blue"]
for d,i in enumerate(color):
    print(i,d)
