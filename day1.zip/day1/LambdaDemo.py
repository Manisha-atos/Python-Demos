cube = lambda a:a*a*a;

print(cube(2));
