list1 = [12, 14,14,12, 16, 18, 20]  
print(list1)
print(list1[2:4])
print(list1[-5:-2])

'''list1.insert(2,100)
print(14 in list1)
print(len(list1))
print(list1.count(14))
print(list1.index(12,1,5))
#Repetation
l=list1*2
print(l)
list2 = [9, 10, 32, 54, 86]  
#concatenation
print(list1+list2)
#length
print(len(list1))
#iteration
for i in list1:   
    print(i)  ;
    #membership
print(10 in list1 )
list1.append(1000)
print(list1)
list1.remove(14)
print(list1)
list1.clear()
print(len(list1))'''