print("Hello");
a="Manisha";
print(a);
b=2;
c=3;
print(b+c);
print(id(a));
print(id(b));
print(id(c));
print(type(a))
print(type(True))  
print(type(False))  




