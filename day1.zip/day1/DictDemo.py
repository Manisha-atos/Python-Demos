Employee = {"Name": "Johnny", "Age": 32, "salary":26000,"Company":"^TCS"}        
print(type(Employee))        
print("printing Employee data .... ")        
print(Employee)    
 

Dict = {}       
print("Empty Dictionary: ")       
print(Dict)   

  
 #Creating a Dictionary       
# with dict() method       
Dict = dict({1: 'Hcl', 2: 'WIPRO', 3:'Facebook'})       
print("\nCreate Dictionary by using  dict(): ")       
print(Dict)       
    
# Creating a Dictionary       
# with each item as a Pair       
Dict = dict([(4, 'Rinku'), (2, "Singh"
)])       
print("\nDictionary with each item as a pair: ")       
print(Dict)   
print(type(Dict))

